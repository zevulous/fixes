# Building the dataset on Windows (PowerShell)

Complete rebuild from public sources. No data files are distributed — this
guide plus the scripts in `scripts/` reproduce everything.

**Time:** ~45 min for the DEM and grade pipeline, plus ~3.5 h for the optional
ICESat-2 validation.
**Disk:** 25 GB during the build, ~1 GB of outputs after cleanup.
**Downloads:** ~12 GB.

Run everything in **PowerShell 7+** (`pwsh`). Windows PowerShell 5.1 works for
most steps but lacks `ForEach-Object -Parallel`; a fallback is given where it
matters.

---

## Step 0 — Prerequisites

### 0.1 Install Miniforge

Miniforge gives you conda-forge by default, which is the only reliable way to
get GDAL with all codecs on Windows. Download and run the installer from
<https://github.com/conda-forge/miniforge/releases> (pick
`Miniforge3-Windows-x86_64.exe`).

During install, tick **"Add Miniforge3 to my PATH"**. If you skip that, use the
"Miniforge Prompt" from the Start menu instead of plain PowerShell.

Verify in a **new** terminal:

```powershell
conda --version
```

### 0.2 Create the environment

```powershell
conda create -n phdem -c conda-forge -y `
    python=3.11 gdal libgdal-core rasterio geopandas shapely pyproj `
    scipy pandas numpy pyarrow awscli requests

conda activate phdem
```

Your prompt should now start with `(phdem)`. You need this active in every
terminal you use for this build.

```powershell
gdalinfo --version
python --version
aws --version
```

### 0.3 Install pip-only packages

```powershell
pip install fabdem sliderule
```

### 0.4 Enable the geoid grid

PROJ needs the EGM2008 grid for the vertical datum conversion in the
validation step. **This is important**: without it, `pyproj` silently returns
input coordinates unchanged rather than raising, producing results wrong by
~43 m with no error.

```powershell
[Environment]::SetEnvironmentVariable("PROJ_NETWORK", "ON", "User")
$env:PROJ_NETWORK = "ON"
pyproj sync --source-id us_nga_egm08 --verbose
```

Test it:

```powershell
python -c "from pyproj import Transformer; t=Transformer.from_crs('EPSG:4979','EPSG:4326+3855',always_xy=True); print(t.transform(121.0,14.6,0.0))"
```

You want a third value near **-43**. If you get `0.0`, the grid is not active
and the validation step will be wrong — fix this before continuing.

### 0.5 Working directory

```powershell
New-Item -ItemType Directory -Force -Path $HOME\ph_dem | Out-Null
Set-Location $HOME\ph_dem
Get-PSDrive C | Select-Object Used, Free
```

Copy the `scripts/` folder from this repo into `$HOME\ph_dem\`.

### 0.6 Keep the machine awake

Long steps will fail if the machine sleeps. Either change the power plan in
Settings, or run this in a second terminal and leave it:

```powershell
powercfg /requestsoverride PROCESS pwsh.exe DISPLAY SYSTEM AWAYMODE
```

---

## Step 1 — Copernicus GLO-30

```powershell
aws s3 cp --no-sign-request s3://copernicus-dem-30m/tileList.txt .

$pattern = 'Copernicus_DSM_COG_10_N(0[4-9]|1[0-9]|2[01])_00_E(11[6-9]|12[0-6])_00_DEM'
Select-String -Path tileList.txt -Pattern $pattern -AllMatches |
    ForEach-Object { $_.Matches.Value } |
    Sort-Object -Unique |
    Set-Content ph_tiles.txt

(Get-Content ph_tiles.txt).Count
```

Expect **109**. If you get 0, the bucket naming has changed and the regex needs
updating.

Fetching from the manifest rather than constructing tile names means only
tiles that actually exist are requested — ocean cells are absent from the
bucket.

### Download (PowerShell 7)

```powershell
New-Item -ItemType Directory -Force -Path tiles | Out-Null
$tiles = Get-Content ph_tiles.txt
$tiles | ForEach-Object -ThrottleLimit 8 -Parallel {
    aws s3 cp --no-sign-request --only-show-errors `
        "s3://copernicus-dem-30m/$_/$_.tif" "tiles/$_.tif"
}
(Get-ChildItem tiles\*.tif).Count
```

### Download (PowerShell 5.1 fallback — slower, serial)

```powershell
New-Item -ItemType Directory -Force -Path tiles | Out-Null
foreach ($t in Get-Content ph_tiles.txt) {
    aws s3 cp --no-sign-request --only-show-errors "s3://copernicus-dem-30m/$t/$t.tif" "tiles/$t.tif"
}
```

### Verify

A truncated download fails silently and only surfaces deep inside a later
long-running warp, so check now:

```powershell
foreach ($f in Get-ChildItem tiles\*.tif) {
    $null = gdalinfo $f.FullName 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Host "BAD: $($f.Name)" -ForegroundColor Red }
}
"{0} tiles, {1:N1} GB" -f (Get-ChildItem tiles\*.tif).Count,
    ((Get-ChildItem tiles\*.tif | Measure-Object Length -Sum).Sum / 1GB)
```

Want 109 tiles, ~1.5 GB, no `BAD:` lines. Re-run the download to fix any
failures — it only re-fetches what is missing.

---

## Step 2 — Land boundary

Download the Philippines shapefile from
<https://gadm.org/download_country.html> (select Philippines, shapefile
format), then:

```powershell
Expand-Archive -Path "$HOME\Downloads\gadm41_PHL_shp.zip" -DestinationPath gadm -Force
Get-ChildItem gadm\gadm41_PHL_0.*
```

You need `gadm41_PHL_0.shp` plus its `.dbf`, `.shx`, `.prj` siblings.

---

## Step 3 — Build the GLO-30 mosaic

```powershell
$PROJ = '+proj=lcc +lat_1=7 +lat_2=19 +lat_0=13 +lon_0=122 +datum=WGS84 +units=m +no_defs'

gdalbuildvrt -overwrite ph_glo30.vrt (Get-ChildItem tiles\*.tif).FullName

gdalwarp -overwrite -t_srs "$PROJ" -tr 30 30 -r bilinear `
  -dstnodata -9999 -multi -wo NUM_THREADS=ALL_CPUS `
  -co COMPRESS=DEFLATE -co PREDICTOR=3 -co TILED=YES -co BIGTIFF=YES `
  ph_glo30.vrt ph_dem_30m.tif
```

### Land mask — not optional

Copernicus encodes ocean as elevation **0**, not nodata. Without clipping,
every coastline becomes a 0-to-terrain step that `gdaldem slope` correctly
reports as a near-vertical cliff.

```powershell
gdalwarp -overwrite -cutline gadm\gadm41_PHL_0.shp -crop_to_cutline `
  -dstnodata -9999 -multi -wo NUM_THREADS=ALL_CPUS `
  -co COMPRESS=DEFLATE -co PREDICTOR=3 -co TILED=YES -co BIGTIFF=YES `
  ph_dem_30m.tif ph_dem_30m_land.tif
```

Roughly 4 minutes — clipping against thousands of island polygons is the
expensive part.

---

## Step 4 — FABDEM

FABDEM is Copernicus GLO-30 with forest canopy and buildings removed. It is
the primary elevation source; see METHODOLOGY §2.1.

```powershell
python -c "import fabdem; fabdem.download((116,4,127,21), output_path='fabdem_ph_raw.tif', show_progress=True)"
```

~20 minutes, ~9 GB. Verify:

```powershell
gdalinfo fabdem_ph_raw.tif | Select-String "Size is|Pixel Size"
```

Expect `Size is 39600, 61200` and a pixel size of 0.000277777777778.

### Warp onto the identical grid

Pixel alignment matters: the reliability covariate is a pixel-wise difference
between the two DEMs, and misregistration would inject a terrain-correlated
artefact into exactly that variable.

```powershell
$b = python -c "import rasterio; s=rasterio.open('ph_dem_30m_land.tif'); b=s.bounds; print(b.left,b.bottom,b.right,b.top)"
$xmin,$ymin,$xmax,$ymax = $b -split '\s+'
Write-Host "bounds: $xmin $ymin $xmax $ymax"

gdalwarp -overwrite -t_srs "$PROJ" -tr 30 30 `
  -te $xmin $ymin $xmax $ymax -r bilinear `
  -dstnodata -9999 -multi -wo NUM_THREADS=ALL_CPUS `
  -co COMPRESS=DEFLATE -co PREDICTOR=3 -co TILED=YES -co BIGTIFF=YES `
  fabdem_ph_raw.tif ph_fabdem_30m.tif
```

Warnings about `-9999` being "changed to -9999" are benign — FABDEM already
uses that as nodata.

### Confirm the grids match exactly

```powershell
python -c "import rasterio; [print(f, rasterio.open(f).shape, rasterio.open(f).bounds) for f in ['ph_dem_30m_land.tif','ph_fabdem_30m.tif']]"
```

Both lines must show `(60617, 35551)` with identical bounds. If they differ,
stop and re-run the warp — everything downstream depends on this.

```powershell
Remove-Item fabdem_ph_raw.tif    # 9 GB, no longer needed
```

---

## Step 5 — Slope raster

```powershell
gdaldem slope ph_fabdem_30m.tif ph_slope_raw.tif -alg Horn -compute_edges `
  -co COMPRESS=DEFLATE -co PREDICTOR=3 -co TILED=YES -co BIGTIFF=YES

gdalwarp -overwrite -cutline gadm\gadm41_PHL_0.shp -crop_to_cutline `
  -dstnodata -9999 -multi -wo NUM_THREADS=ALL_CPUS `
  -co COMPRESS=DEFLATE -co PREDICTOR=3 -co TILED=YES -co BIGTIFF=YES `
  ph_slope_raw.tif ph_slope_deg_land.tif

gdaladdo -r average ph_slope_deg_land.tif 2 4 8 16 32
Remove-Item ph_slope_raw.tif
```

Horn's method fits a plane to the 3×3 neighbourhood. Zevenbergen–Thorne is
sharper on smooth terrain but noisier on radar-derived DEMs, which carry
speckle.

### Sanity check

```powershell
gdalinfo -stats ph_slope_deg_land.tif | Select-String "STATISTICS_(MEAN|MAXIMUM)"
```

**Expect mean ≈ 12.06°, max ≈ 75.4°.** A mean under 2° means the land mask
did not apply and you are averaging in ocean.

---

## Step 6 — OpenStreetMap roads

```powershell
$osm = "philippines-latest.osm.pbf"
Invoke-WebRequest -Uri "https://download.geofabrik.de/asia/philippines-latest.osm.pbf" `
    -OutFile $osm
"{0:N0} MB" -f ((Get-Item $osm).Length / 1MB)
```

Expect 300–600 MB. Anything in kilobytes means you got a redirect page —
`Invoke-WebRequest` follows redirects by default, but `curl.exe` does not
unless you pass `-L`.

**Record the resolved filename.** Geofabrik redirects `-latest` to a dated
file (e.g. `philippines-260903.osm.pbf`) and does not serve historical
dailies. Exact reproduction requires keeping this file.

### Promote tags to real columns

GDAL's OSM driver dumps most tags into a catch-all HSTORE column by default.

```powershell
$conf = Join-Path $env:CONDA_PREFIX "Library\share\gdal\osmconf.ini"
Copy-Item $conf .\osmconf.ini
notepad .\osmconf.ini
```

In the `[lines]` section, find the line starting `attributes=` and append to
**that same line**:

```
,bridge,tunnel,layer,incline,surface,oneway
```

Some may already be present; duplicates are harmless. Save and close.

### Extract

```powershell
$env:OSM_CONFIG_FILE = ".\osmconf.ini"
ogr2ogr -f GPKG ph_roads.gpkg $osm lines `
  -where "highway IS NOT NULL" -t_srs "$PROJ" -nln roads

ogrinfo -so ph_roads.gpkg roads | Select-String "Feature Count|incline|bridge|tunnel"
```

Expect ~1.6M features and `incline`, `bridge`, `tunnel` listed as columns.

---

## Step 7 — Compute grade

Test on one road first — this catches configuration errors in 30 seconds
instead of 6 minutes:

```powershell
python scripts\grade.py kennon
```

**Expect core median ≈ 6.9%.** Kennon Road's true sustained grade is 6–10%,
so this validates the whole chain. A p95 near 23% and max near 45% are also
expected — Kennon runs through the Bued gorge and is a deliberate worst case
(METHODOLOGY §5.3).

If the median is wildly off, something upstream is wrong. Do not proceed.

Then the national run:

```powershell
python scripts\grade.py all
```

~6 minutes, ~10 GB RAM peak. Expected output:

```
241047 ways, 194101 km
241047 ways -> 43495 route groups
92435 parts, 9829137 vertices
core |grade| med 1.67%  p95 15.54%
motorway  med 0.42%  p95 4.63%
```

The motorway figure is the strongest check available — Philippine expressways
are designed to 4–6% maximum grade, and nothing in the pipeline knows about
road classification, so recovering that independently means the method works.

---

## Step 8 — ICESat-2 validation (optional, ~3.5 h)

Skip this if you only need the grade data. It produces the external accuracy
statement in METHODOLOGY §7.

```powershell
Start-Process pwsh -ArgumentList "-NoExit","-Command","conda activate phdem; cd $HOME\ph_dem; python scripts\ice_national.py *>&1 | Tee-Object ice_national.log"
```

That opens a separate window so the job survives your main terminal. Monitor:

```powershell
Select-String -Path ice_national.log -Pattern '^\[' | Select-Object -Last 5
(Get-ChildItem ice_tiles\*.parquet).Count
```

You will see a large volume of `Alert <-7>: ... H5Coro::Future read failure`
messages. **These are expected** — server-side HDF5 read errors on individual
beam-tracks, roughly 1–2% of reads, randomly distributed. They constitute
random thinning, not systematic loss. The script is resumable; re-run it to
retry any tile-level `FAIL`.

When it finishes (93 tiles):

```powershell
(Get-ChildItem ice_tiles\*.parquet).Count
(Select-String -Path ice_national.log -Pattern 'FAIL').Count
(Select-String -Path ice_national.log -Pattern 'H5Coro').Count

python scripts\ice_analyze.py
```

**Expected headline:** overall median residual -0.34 m, IQR 4.76 m; and in the
flat + open stratum, regression slope 0.054, intercept -0.13, median residual
0.01 m on ~110k points.

That last number is the point of the whole exercise. See METHODOLOGY §7.3 for
why the apparently-strong national correction must not be applied.

---

## Step 9 — Compress and package

```powershell
python scripts\compress.py

gdal_translate ph_slope_deg_land.tif data\ph_slope_deg.tif `
  -ot UInt16 -scale 0 90 0 900 -a_nodata 65535 `
  -co COMPRESS=ZSTD -co ZSTD_LEVEL=15 -co PREDICTOR=2 `
  -co TILED=YES -co BLOCKXSIZE=512 -co BLOCKYSIZE=512 `
  -co SPARSE_OK=TRUE -co BIGTIFF=YES -co NUM_THREADS=ALL_CPUS

gdaladdo -r average --config COMPRESS_OVERVIEW ZSTD data\ph_slope_deg.tif 2 4 8 16 32
```

The raster is UInt16 scaled by 10 — **divide by 10 for degrees**, nodata
65535. Verify the round-trip:

```powershell
gdalinfo -stats data\ph_slope_deg.tif | Select-String "STATISTICS_(MEAN|MAXIMUM)"
```

Expect mean ≈ 120.6 and max ≈ 754 (i.e. 12.06° and 75.4°).

### Checksums

```powershell
Get-ChildItem data\* | Get-FileHash -Algorithm SHA256 |
    ForEach-Object { "{0}  {1}" -f $_.Hash.ToLower(), (Split-Path $_.Path -Leaf) } |
    Set-Content data\MANIFEST.txt
Get-Content data\MANIFEST.txt
```

### Clean up intermediates

```powershell
Remove-Item -Recurse -Force tiles, ice_tiles, ph_glo30.vrt, ph_dem_30m.tif
Get-ChildItem data\ | Format-Table Name, @{n='MB';e={[int]($_.Length/1MB)}}
```

Keep `philippines-*.osm.pbf` — it is the reproducibility anchor and cannot be
re-downloaded once Geofabrik rotates it.

---

## Expected results summary

Use these to confirm your rebuild matches. Small differences in the road
counts are expected because OSM changes daily; the grade statistics should be
stable to within a few hundredths of a percent.

| Check | Expected |
|---|---|
| GLO-30 tiles | 109 |
| Grid shape | 60617 × 35551 |
| Slope raster mean / max | 12.06° / 75.4° |
| OSM features (all highway) | ~1.6M |
| Ways in six road classes | ~241,000 |
| Network length | ~194,100 km |
| Route groups | ~43,500 |
| Vertices | ~9.83M |
| Kennon Road core median | ~6.9% |
| National core median / p95 | 1.67% / 15.54% |
| Motorway median / p95 | 0.42% / 4.63% |
| ICESat-2 tiles | 93 |
| ICESat-2 overall median / IQR | -0.34 m / 4.76 m |
| Flat+open regression slope | 0.054 |

---

## Troubleshooting

**`aws: command not found`** — the conda env is not active. Run
`conda activate phdem`.

**Geoid transform returns 0.0** — the EGM2008 grid is missing. Re-run
`pyproj sync --source-id us_nga_egm08 --verbose` and confirm
`$env:PROJ_NETWORK` is `ON`. Do not proceed to Step 8 without this.

**`gdalwarp` complains about too few arguments to `-te`** — PowerShell splits
variables differently from bash. Use the four separate `$xmin $ymin $xmax
$ymax` variables as shown, not a single combined string.

**Grid shapes differ between the two DEMs** — the `-te` values did not apply.
Re-run Step 4's warp with the bounds printed explicitly.

**`grade.py` reports "no segments matched"** — `ph_roads.gpkg` is missing or
has no `roads` layer. Re-run Step 6 and check the `ogrinfo` output.

**MemoryError in `grade.py all`** — the national run peaks around 10 GB. Run
`kennon` mode to verify the pipeline, then either add RAM, use a machine with
more, or reduce `CLASSES` in `scripts/grade.py` to fewer road types.

**ZSTD not available in `gdal_translate`** — fall back to
`-co COMPRESS=DEFLATE -co ZLEVEL=9 -co PREDICTOR=2`. The UInt16 conversion
does most of the compression work regardless of codec.
