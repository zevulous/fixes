# Philippine National Road Grade Dataset

A reproducible pipeline producing terrain-following road grade for **194,101 km**
of the Philippine road network, plus a national bare-earth slope raster. Built
entirely from open data and validated against satellite laser altimetry.

> **Screening product. Not engineering-grade. Not for road design.**
> The roadway is narrower than one DEM pixel, so values describe the terrain a
> road traverses, not its engineered running surface. See
> [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md) §0 for what this means in practice.

## Why this exists

There is no openly available road grade data for the Philippines. The correct
data exists — NAMRIA holds a nationwide 5 m IfSAR DTM, DPWH holds surveyed
as-built profiles for the 35,000 km national network, UP TCAGP holds 1 m LiDAR
for major floodplains — but all three require institutional access. Meanwhile
OpenStreetMap's `incline` tag covers **eight** road features nationally, all
round-number mapper estimates.

This fills that gap with a characterised approximation: not as good as survey
data, but with its uncertainty measured rather than assumed.

## Key results

- Median grade **1.67%**, p95 **15.54%** across 9.2M core vertices
- Motorway class median **0.42%**, p95 **4.63%** — independently recovers
  expressway design standards from a 30 m DEM, with no knowledge of road class
  anywhere in the pipeline
- FABDEM validated **unbiased** against ICESat-2 in flat open terrain:
  median residual 0.01 m, regression slope 0.054, n = 110,313
- **73%** of the network (134,559 km) in high or moderate reliability tiers
- A plausible national bias correction was fitted and **rejected** — see below

### The correction that wasn't

Regressing DEM error on the disagreement between two elevation models gave
near-identical coefficients across Luzon, Visayas, and Mindanao (slopes 1.076,
0.957, 1.005). Three independent regions agreeing that closely normally
indicates a real relationship, and applying it would have halved vertical
scatter.

Stratifying first showed the slope is **0.054 in flat open terrain** and rises
to 1.59 on steep slopes and 1.36 under canopy — the relationship is an artefact
of ICESat-2's own ground-classification error, not a property of the DEMs.
Applying it would have imported the reference's bias while appearing to improve
internal consistency. Detail in [METHODOLOGY §7.3](docs/METHODOLOGY.md).

## Building it

No data files are distributed. The pipeline rebuilds everything from public
sources in about 45 minutes, plus 3.5 hours for the optional ICESat-2
validation.

**[→ BUILD_WINDOWS.md](BUILD_WINDOWS.md)** — complete step-by-step PowerShell
instructions, with expected output at every stage so you can verify your build.

```powershell
conda env create -f environment.yml
conda activate phdem
# then follow BUILD_WINDOWS.md
```

macOS/Linux users: the Python scripts are platform-independent; translate the
PowerShell in the build guide to bash (`Invoke-WebRequest` → `curl -L -O`,
`Get-FileHash` → `shasum -a 256`, backtick continuations → backslash).

## What you get

| Output | Description |
|---|---|
| `ph_road_grade.parquet` | 185k road ways with grade stats, reliability tier, geometry (GeoParquet) |
| `ph_road_grade_ways.parquet` | Same, no geometry — ~3 MB |
| `ph_road_grade_vertices.parquet` | 9.83M vertices, full per-point detail |
| `ph_slope_deg.tif` | National bare-earth slope, 30 m, UInt16 scaled ×10 |
| `ice_residuals.parquet` | 857k ICESat-2 validation residuals |

Per-way columns: `grade_med`, `grade_p95`, `grade_max`, `reliability`,
`pct_low_or_worse`, `disagree_med`, `length_m`, `n_vert`, joinable to
OpenStreetMap on `osm_id`.

**Integer encoding:** the vertices file and slope raster use scaled integers.
`-32768` (int16) and `65535` (raster) are NA sentinels and must be filtered.
Full schema in [METHODOLOGY §12](docs/METHODOLOGY.md).

## Reliability tiers

Grade quality is stratified by disagreement between the two source DEMs — a
proxy for terrain complexity, externally validated against ICESat-2.

| Tier | Share | Length | Median grade | p95 |
|---|---|---|---|---|
| high | 28.5% | 52,622 km | 0.60% | 9.88% |
| moderate | 44.4% | 81,937 km | 1.42% | 12.48% |
| low | 25.1% | 46,210 km | 4.91% | 20.34% |
| unreliable | 1.9% | 3,571 km | 8.07% | 29.10% |

These flag **noise**, not correctable bias. ICESat-2 residual IQR rises from
1.82 m to 16.42 m across the same strata while medians stay near zero.

## Sources

FABDEM v1.2 · Copernicus DEM GLO-30 · OpenStreetMap (Geofabrik) · GADM 4.1 ·
ICESat-2 ATL08 via SlideRule · EGM2008

## Licence

**Code: MIT** (see `LICENSE`).

**Data you generate: CC BY-NC-SA 4.0**, inherited from FABDEM — non-commercial
and share-alike. Required attributions in
[METHODOLOGY §10](docs/METHODOLOGY.md).

If you need commercial rights, the pipeline runs on Copernicus GLO-30 alone
(which is freely licensed) at the cost of the canopy correction, and therefore
materially worse grades under forest.
