#!/usr/bin/env python3
"""
ICESat-2 vs FABDEM residual analysis, streamed by tile.

Produces the validation in METHODOLOGY section 7, including the stratified
regression test that rejects a naive national bias correction.

Usage:
    python ice_analyze.py

Requires: numpy pandas rasterio scipy pyproj pyarrow
Requires PROJ_NETWORK=ON or a locally cached EGM2008 grid.
"""
import glob

import numpy as np
import pandas as pd
import rasterio
from scipy.ndimage import map_coordinates
from pyproj import Transformer

LCC = ("+proj=lcc +lat_1=7 +lat_2=19 +lat_0=13 +lon_0=122 "
       "+datum=WGS84 +units=m +no_defs")
SUB = 40          # keep 1 in N points; a few million is ample for model fitting

to_lcc = Transformer.from_crs("EPSG:4326", LCC, always_xy=True)
geoid = Transformer.from_crs("EPSG:4979", "EPSG:4326+3855", always_xy=True)


def geoid_sep(lon, lat):
    """
    EGM2008 separation, guarded.

    pyproj returns input coordinates UNCHANGED when the grid is unavailable --
    a silent no-op that produces a plausible-looking answer wrong by ~43 m.
    The threshold is safe because separation is nowhere near zero in the
    Philippines.
    """
    _, _, h0 = geoid.transform(lon, lat, np.zeros_like(lon))
    N = -np.asarray(h0)
    if np.abs(N).max() < 1.0:
        raise RuntimeError(
            "geoid transform inactive -- EGM2008 grid missing. "
            "Set PROJ_NETWORK=ON or run: pyproj sync --source-id us_nga_egm08")
    return N


def sample(src, X, Y):
    c, r = (~src.transform) * (X, Y)
    ok = (r >= 1) & (r < src.height - 1) & (c >= 1) & (c < src.width - 1)
    out = np.full(len(X), np.nan)
    if not ok.any():
        return out
    r0, c0 = int(np.nanmin(r[ok])) - 1, int(np.nanmin(c[ok])) - 1
    h = int(np.nanmax(r[ok])) - r0 + 3
    w = int(np.nanmax(c[ok])) - c0 + 3
    b = src.read(1, window=((r0, r0 + h), (c0, c0 + w))).astype("float64")
    if src.nodata is not None:
        b[b == src.nodata] = np.nan
    out[ok] = map_coordinates(b, [r[ok] - r0, c[ok] - c0], order=1, mode="nearest")
    return out


def main():
    src = {k: rasterio.open(v) for k, v in {
        "fab": "ph_fabdem_30m.tif",
        "glo": "ph_dem_30m_land.tif",
        "slp": "ph_slope_deg_land.tif"}.items()}

    keep = []
    files = sorted(glob.glob("ice_tiles/*.parquet"))
    if not files:
        raise SystemExit("no tiles in ice_tiles/ -- run ice_national.py first")

    for i, f in enumerate(files, 1):
        try:
            d = pd.read_parquet(f)
        except Exception:
            continue
        if not len(d):
            continue
        d = d.iloc[::SUB]
        if not len(d):
            continue
        lon, lat = d.lon.values, d.lat.values
        N = geoid_sep(lon, lat)
        X, Y = to_lcc.transform(lon, lat)
        fab, glo, slp = (sample(src[k], X, Y) for k in ("fab", "glo", "slp"))
        keep.append(pd.DataFrame({
            "lon": lon, "lat": lat,
            "resid": (d.h_te_median.values - N) - fab,
            "disagree": glo - fab,
            "slope": slp,
            "canopy": d.h_canopy.values,
            "gnd": d.gnd_ph_count.values,
            "night": d.solar_elevation.values < 0,
        }))
        if i % 10 == 0:
            print("%d/%d" % (i, len(files)), flush=True)

    a = pd.concat(keep, ignore_index=True)
    a = a.replace([np.inf, -np.inf], np.nan).dropna()
    a = a[a.resid.abs() < 200]
    a.to_parquet("ice_residuals.parquet", index=False)
    print("\nn = %d (1 in %d sampled)" % (len(a), SUB))

    iqr = lambda x: np.percentile(x, 75) - np.percentile(x, 25)

    def rep(name, col, bins):
        b = pd.cut(a[col], bins)
        print("\n-- %s --" % name)
        print(a.groupby(b, observed=True).resid.agg(
            n="size", med="median", iqr=iqr).round(2).to_string())

    print("overall  med %.2f  IQR %.2f  MAD %.2f"
          % (a.resid.median(), iqr(a.resid),
             np.median(np.abs(a.resid - a.resid.median()))))
    rep("DEM disagreement (m)", "disagree", [-1e9, -15, -5, -1, 1, 5, 15, 1e9])
    rep("slope (deg)", "slope", [0, 5, 10, 20, 30, 90])
    rep("canopy (m)", "canopy", [-1e9, 1, 5, 15, 1e9])

    # ---- does one national correction hold? ----
    a["region"] = np.where(a.lat > 13, "Luzon",
                  np.where(a.lat > 9, "Visayas", "Mindanao/Palawan"))
    m = a.disagree.abs() < 30
    print("\n-- disagreement regression by region --")
    for reg, g in a[m].groupby("region"):
        if len(g) < 1000:
            continue
        z = np.polyfit(g.disagree, g.resid, 1)
        print("%-18s n=%8d  slope %.3f  intercept %6.2f" % (reg, len(g), z[0], z[1]))

    # ---- THE TEST THAT MATTERS ----
    # If the regional slopes above agree near 1.0 it looks like a real,
    # correctable relationship. Stratifying reveals whether it is instead an
    # artefact of ICESat-2 ground-classification error under canopy and on
    # slopes. See METHODOLOGY 7.3.
    print("\n-- regression by canopy stratum --")
    for lo, hi in [(-1e9, 1), (1, 5), (5, 15), (15, 1e9)]:
        g = a[m & (a.canopy > lo) & (a.canopy <= hi)]
        if len(g) < 2000:
            continue
        z = np.polyfit(g.disagree, g.resid, 1)
        print("canopy %6.0f-%6.0f m  n=%7d  slope %.3f  int %6.2f"
              % (lo, hi, len(g), z[0], z[1]))

    print("\n-- regression by slope stratum --")
    for lo, hi in [(0, 5), (5, 10), (10, 20), (20, 90)]:
        g = a[m & (a.slope > lo) & (a.slope <= hi)]
        if len(g) < 2000:
            continue
        z = np.polyfit(g.disagree, g.resid, 1)
        print("slope %3d-%3d deg  n=%7d  slope %.3f  int %6.2f"
              % (lo, hi, len(g), z[0], z[1]))

    print("\n-- CLEANEST STRATUM: flat (<5 deg) + open (<1 m canopy) --")
    g = a[m & (a.slope < 5) & (a.canopy < 1)]
    z = np.polyfit(g.disagree, g.resid, 1)
    print("n=%d  slope %.3f  int %.2f  median resid %.2f"
          % (len(g), z[0], z[1], g.resid.median()))
    print("\nA slope near zero here means DEM disagreement carries NO "
          "information about\nFABDEM error where the reference data is "
          "trustworthy -- i.e. the apparent\nnational correction is a "
          "reference-data artefact and must NOT be applied.")


if __name__ == "__main__":
    main()
