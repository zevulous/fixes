#!/usr/bin/env python3
"""
Compress release files with bounded-loss quantization.

Reduces the vector outputs from ~860 MB to ~265 MB. All quantization is one
to two orders of magnitude below the measured error floor (METHODOLOGY 7.4).

Encoding is documented in METHODOLOGY section 12. The key trap: -32768 is the
NA sentinel in int16 columns and MUST be filtered before use.

Usage:
    python compress.py

Requires: numpy pandas geopandas pyarrow (with zstd support)
"""
import os

import numpy as np
import pandas as pd
import geopandas as gpd

NA16 = -32768
OUT = "data"


def mb(p):
    return os.path.getsize(p) / 1e6


def to_i16(s, scale, lo, hi):
    """Scale, round, clip, fill NA with sentinel, cast to int16."""
    return (s.clip(lo, hi) * scale).round().fillna(NA16).astype("int16")


def main():
    os.makedirs(OUT, exist_ok=True)

    # ---------------------------------------------------------- vertices
    print("vertices: reading...")
    v = pd.read_parquet("ph_road_grade_vertices.parquet")
    before = mb("ph_road_grade_vertices.parquet")

    # way-level attrs live in the ways file, joinable on osm_id
    drop = [c for c in ["grade_deg", "z_dsm", "name", "bridge", "tunnel", "surface"]
            if c in v]
    v = v.drop(columns=drop)
    print("  dropped:", drop)
    print("  NaN: z=%d disagree=%d grade=%d"
          % (v.z_dtm.isna().sum(), v.dem_disagree_m.isna().sum(),
             v.grade_pct.isna().sum()))

    o = pd.DataFrame()
    o["osm_id"] = pd.to_numeric(v.osm_id, errors="coerce").fillna(0).astype("int64")
    o["part_id"] = v.part_id.astype("int32")
    o["x_dm"] = (v.x * 10).round().astype("int32")
    o["y_dm"] = (v.y * 10).round().astype("int32")
    o["dist_dm"] = (v.dist_m * 10).round().astype("int32")
    o["z_dm"] = to_i16(v.z_dtm, 10, -3200, 3200)
    o["disag_dm"] = to_i16(v.dem_disagree_m, 10, -3200, 3200)
    o["grade_cpct"] = to_i16(v.grade_pct, 100, -320, 320)
    o["highway"] = v.highway.astype("category")
    o["reliability"] = v.reliability.astype("category")
    o["structure"] = v.structure.astype(bool)
    o["edge"] = v.edge.astype(bool)

    # sorting by route then distance helps run-length and delta encoding
    o = o.sort_values(["part_id", "dist_dm"]).reset_index(drop=True)
    o.to_parquet(OUT + "/ph_road_grade_vertices.parquet", index=False,
                 compression="zstd", compression_level=19,
                 use_dictionary=True, row_group_size=200_000)
    print("  %.0f MB -> %.0f MB" % (before, mb(OUT + "/ph_road_grade_vertices.parquet")))
    del v, o

    # ---------------------------------------------------------- ways
    w = pd.read_parquet("ph_road_grade_ways.parquet")
    before = mb("ph_road_grade_ways.parquet")
    for c in ["grade_med", "grade_p95", "grade_max", "disagree_med",
              "pct_low_or_worse", "length_m"]:
        if c in w:
            w[c] = w[c].astype("float32")
    if "n_vert" in w:
        w["n_vert"] = w.n_vert.astype("int32")
    for c in ["highway", "reliability"]:
        if c in w:
            w[c] = w[c].astype("category")
    w.to_parquet(OUT + "/ph_road_grade_ways.parquet", index=False,
                 compression="zstd", compression_level=19)
    print("ways: %.1f MB -> %.1f MB" % (before, mb(OUT + "/ph_road_grade_ways.parquet")))

    # ---------------------------------------------------------- geometry
    g = gpd.read_parquet("ph_road_grade.parquet")
    before = mb("ph_road_grade.parquet")
    for c in ["grade_med", "grade_p95", "grade_max", "disagree_med",
              "length_m", "pct_low_or_worse"]:
        if c in g:
            g[c] = g[c].astype("float32")
    for c in ["highway", "reliability"]:
        if c in g:
            g[c] = g[c].astype("category")
    g.to_parquet(OUT + "/ph_road_grade.parquet",
                 compression="zstd", compression_level=19)
    print("geom: %.0f MB -> %.0f MB" % (before, mb(OUT + "/ph_road_grade.parquet")))

    # ---------------------------------------------------------- residuals
    if os.path.exists("ice_residuals.parquet"):
        r = pd.read_parquet("ice_residuals.parquet")
        before = mb("ice_residuals.parquet")
        for c in r.columns:
            if r[c].dtype == "float64":
                r[c] = r[c].astype("float32")
        r.to_parquet(OUT + "/ice_residuals.parquet", index=False,
                     compression="zstd", compression_level=19)
        print("resid: %.1f MB -> %.1f MB" % (before, mb(OUT + "/ice_residuals.parquet")))


if __name__ == "__main__":
    main()
