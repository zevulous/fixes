#!/usr/bin/env python3
"""
National ICESat-2 ATL08 terrain sample via SlideRule, tiled and resumable.

Retrieves PhoREAL-processed terrain heights for 1-degree cells intersecting
the Philippine land boundary. Writes one parquet per tile so the job can be
interrupted and restarted without losing work.

Runtime ~3.2 hours for 93 tiles. Output ~5 GB, ~150M points.

Usage:
    python ice_national.py

Requires: sliderule geopandas pandas numpy shapely pyarrow
Requires a NASA Earthdata account (free, automatic registration at
urs.earthdata.nasa.gov) -- but note SlideRule handles the data access
server-side, so credentials are not needed for this script itself.
"""
import os
import sys
import time
import glob

import numpy as np
import pandas as pd
import geopandas as gpd
import sliderule
from sliderule import icesat2
from shapely.geometry import box

TILE = 1.0                              # degrees
OUTDIR = "ice_tiles"
T0, T1 = "2019-01-01", "2025-12-31"     # narrow to trade track density for speed
LAND = "gadm/gadm41_PHL_0.shp"
LON_RANGE = (116, 127)
LAT_RANGE = (4, 21)

KEEP = ["h_te_median", "h_canopy", "gnd_ph_count", "ph_count",
        "solar_elevation", "landcover", "snowcover", "cycle", "rgt", "spot"]


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    sliderule.init("slideruleearth.io", verbose=False)

    land = gpd.read_file(LAND).geometry.union_all()
    tiles = []
    for lo in np.arange(LON_RANGE[0], LON_RANGE[1], TILE):
        for la in np.arange(LAT_RANGE[0], LAT_RANGE[1], TILE):
            if box(lo, la, lo + TILE, la + TILE).intersects(land):
                tiles.append((round(lo, 1), round(la, 1)))
    print("%d land tiles" % len(tiles), flush=True)

    done = {os.path.basename(f) for f in glob.glob(OUTDIR + "/*.parquet")}
    t_start = time.time()

    for i, (lo, la) in enumerate(tiles, 1):
        name = "t_%06.2f_%05.2f.parquet" % (lo, la)
        if name in done:
            print("[%3d/%d] skip %s" % (i, len(tiles), name), flush=True)
            continue

        poly = [{"lon": lo, "lat": la},
                {"lon": lo + TILE, "lat": la},
                {"lon": lo + TILE, "lat": la + TILE},
                {"lon": lo, "lat": la + TILE},
                {"lon": lo, "lat": la}]
        parms = {"poly": poly, "srt": 0, "phoreal": {}, "t0": T0, "t1": T1}

        t0 = time.time()
        try:
            g = icesat2.atl08p(parms)
        except Exception as e:
            print("[%3d/%d] FAIL %s : %s" % (i, len(tiles), name, e), flush=True)
            continue

        if g is None or not len(g):
            pd.DataFrame().to_parquet(OUTDIR + "/" + name)
            print("[%3d/%d] %s empty" % (i, len(tiles), name), flush=True)
            continue

        # gnd_ph_count > 0 is MANDATORY: segments with no ground photons report
        # h_te_median = 0.0 as a null sentinel, which would otherwise appear as
        # thousands of phantom sea-level points.
        g = g[(g.gnd_ph_count > 0) & (g.h_te_median > -100) & (g.h_te_median < 3500)]

        if len(g):
            d = pd.DataFrame({k: g[k].values for k in KEEP if k in g.columns})
            d["lon"] = g.geometry.x.values
            d["lat"] = g.geometry.y.values
            d.to_parquet(OUTDIR + "/" + name, index=False)
        else:
            pd.DataFrame().to_parquet(OUTDIR + "/" + name)

        el = time.time() - t_start
        print("[%3d/%d] %s  n=%d  %.0fs  (elapsed %.1fh, eta %.1fh)"
              % (i, len(tiles), name, len(g), time.time() - t0,
                 el / 3600, el / 3600 * (len(tiles) - i) / max(i, 1)), flush=True)

    print("done", flush=True)


if __name__ == "__main__":
    main()
