#!/usr/bin/env python3
"""
Terrain-following road grade from a bare-earth DEM.

SCREENING PRODUCT. Not design-grade. Grade is computed along OSM centrelines
over a 30 m DEM; the roadway is narrower than one pixel, so values reflect the
terrain a road traverses, not the engineered running surface.

Usage:
    python grade.py [kennon|all]

    kennon  -- Kennon Road only, ~30 s, use to verify the pipeline works
    all     -- full national network, ~6 min, ~10 GB RAM peak

Outputs:
    <out>_vertices.parquet   per-vertex detail (9.8M rows nationally)
    <out>_ways.parquet       per-way summary
    <out>.parquet            per-way summary with geometry (GeoParquet)

Platform-independent. Requires: numpy pandas geopandas rasterio shapely scipy pyarrow
"""
import sys
import time
from collections import defaultdict

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from shapely.geometry import MultiLineString
from shapely.ops import linemerge
from scipy.ndimage import map_coordinates
from scipy.signal import savgol_filter

# ----------------------------------------------------------------- config
ROADS = "ph_roads.gpkg"
DTM = "ph_fabdem_30m.tif"        # bare-earth   (FABDEM v1.2)
DSM = "ph_dem_30m_land.tif"      # surface      (Copernicus GLO-30)

CLASSES = ["motorway", "trunk", "primary", "secondary", "tertiary", "unclassified"]

SPACING = 20.0      # m between profile vertices
SMOOTH = 9          # pre-smoothing window in vertices (odd); 9 * 20 m = 180 m
RUN = 100.0         # m over which grade is defined -- see METHODOLOGY 4.6
MIN_LEN = 60.0      # drop route parts shorter than this
SNAP = 1.0          # m tolerance for treating way endpoints as coincident
CHUNK = 200_000     # vertices per spatial-join chunk
MAX_JOIN_DIST = 40.0  # m; cap on sjoin_nearest so vertices cannot grab a road
                      # on the far side of a valley

MODES = {
    "kennon": "name LIKE '%%Kennon%%'",
    "all": None,
}


# ----------------------------------------------------------------- helpers
def log(msg, _t0=[time.time()]):
    print("[%7.1fs] %s" % (time.time() - _t0[0], msg), flush=True)


def build_routes(geoms, snap=SNAP):
    """
    Union-find over snapped way endpoints -> lists of indices forming chains.

    OSM splits ways wherever a tag changes, not at physically meaningful
    breaks. Profiling each way independently computes a derivative on an
    arbitrarily truncated signal. This regroups them into continuous routes.
    """
    key = lambda p: (round(p[0] / snap), round(p[1] / snap))
    at = defaultdict(list)
    for i, g in enumerate(geoms):
        c = g.coords
        at[key(c[0])].append(i)
        at[key(c[-1])].append(i)

    parent = list(range(len(geoms)))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for ids in at.values():
        r = find(ids[0])
        for j in ids[1:]:
            rj = find(j)
            if rj != r:
                parent[rj] = r

    groups = defaultdict(list)
    for i in range(len(geoms)):
        groups[find(i)].append(i)
    return list(groups.values())


def densify(line, step):
    """Vertices at fixed interval along a line. OSM's native vertex spacing is
    wildly non-uniform (dense on curves, sparse on straights) and would bias
    the derivative toward curves."""
    n = max(int(np.ceil(line.length / step)), 1)
    d = np.linspace(0.0, line.length, n + 1)
    xy = np.array([line.interpolate(x).coords[0] for x in d])
    return xy, d


def sample_raster(path, xy, tile=4096):
    """
    Bilinear sample through windowed reads. Never loads the full raster --
    the national grid is 2.155e9 pixels.

    Bilinear (order=1) is essential. Nearest-neighbour would produce a
    staircase elevation profile whose derivative alternates between zero
    and spikes.
    """
    out = np.full(len(xy), np.nan)
    with rasterio.open(path) as src:
        cols, rows = (~src.transform) * (xy[:, 0], xy[:, 1])
        inb = (rows >= 0) & (rows < src.height) & (cols >= 0) & (cols < src.width)
        ri = np.where(inb, rows, 0).astype(np.int64)
        ci = np.where(inb, cols, 0).astype(np.int64)
        for r0 in range(0, src.height, tile):
            for c0 in range(0, src.width, tile):
                m = inb & (ri >= r0) & (ri < r0 + tile) & (ci >= c0) & (ci < c0 + tile)
                if not m.any():
                    continue
                h = min(tile + 1, src.height - r0)
                w = min(tile + 1, src.width - c0)
                blk = src.read(1, window=((r0, r0 + h), (c0, c0 + w))).astype("float64")
                if src.nodata is not None:
                    blk[blk == src.nodata] = np.nan
                out[m] = map_coordinates(
                    blk, [rows[m] - r0, cols[m] - c0], order=1, mode="nearest")
    return out


def profile_grade(z, spacing=SPACING, run=RUN, smooth=SMOOTH):
    """
    Local linear slope via Savitzky-Golay first derivative.

    With polyorder=1, deriv=1 this is mathematically identical to a rolling
    ordinary-least-squares regression of elevation on distance, evaluated at
    each point -- but vectorised. The explicit per-window polyfit is roughly
    1000x slower, which is the difference between the national run being
    feasible and not.

    Regression rather than endpoint differencing: differencing uses two
    samples and discards the rest, amplifying DEM speckle straight into the
    output.
    """
    k = int(round(run / spacing))
    k = max(k + (k % 2 == 0), 5)          # force odd, minimum 5
    if len(z) < k or not np.isfinite(z).all():
        return np.full(len(z), np.nan)
    if len(z) >= smooth:
        z = savgol_filter(z, smooth, 2)
    return savgol_filter(z, k, 1, deriv=1, delta=spacing)


def assign_reliability(disagree):
    """
    Reliability tier from DEM disagreement (GLO30 - FABDEM).

    NOTE: this is NOT canopy height, despite the derivation. Large values in
    EITHER direction indicate terrain where the two DEMs disagree; negative
    values are FABDEM tree-removal artefacts on steep slopes. Empirically
    (METHODOLOGY 7.2) this predicts grade NOISE, not correctable bias.
    """
    a = np.abs(disagree)
    out = np.where(a < 1, "high",
          np.where(a < 5, "moderate",
          np.where(a < 15, "low", "unreliable")))
    # negative disagreement is worse than positive at the same magnitude
    out = np.where((disagree < -5), "unreliable", out)
    out = np.where((disagree < -1) & (disagree >= -5), "low", out)
    return out


# ----------------------------------------------------------------- main
def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "kennon"
    if mode not in MODES:
        sys.exit("mode must be one of: %s" % ", ".join(MODES))

    cls = ",".join("'%s'" % c for c in CLASSES)
    where = "highway IN (%s)" % cls
    if MODES[mode]:
        where += " AND " + MODES[mode]
    out = "kennon_grade" if mode == "kennon" else "ph_road_grade"

    log("reading roads (mode=%s)" % mode)
    gdf = gpd.read_file(ROADS, layer="roads", where=where)
    gdf = gdf.explode(index_parts=False)
    gdf = gdf[gdf.geometry.geom_type == "LineString"].reset_index(drop=True)
    if not len(gdf):
        sys.exit("no segments matched -- check ph_roads.gpkg exists and has a 'roads' layer")
    log("%d ways, %.0f km" % (len(gdf), gdf.geometry.length.sum() / 1000))

    log("building routes")
    groups = build_routes(gdf.geometry.values)
    log("%d ways -> %d route groups" % (len(gdf), len(groups)))

    log("densifying")
    XY, DIST, PART = [], [], []
    pid = 0
    for members in groups:
        merged = linemerge(MultiLineString([gdf.geometry.values[i] for i in members]))
        parts = list(merged.geoms) if merged.geom_type == "MultiLineString" else [merged]
        for part in parts:
            if part.length < MIN_LEN:
                continue
            p, d = densify(part, SPACING)
            XY.append(p)
            DIST.append(d)
            PART.append(np.full(len(d), pid))
            pid += 1
    if not XY:
        sys.exit("no routes survived MIN_LEN")
    xy = np.vstack(XY)
    dist = np.concatenate(DIST)
    part = np.concatenate(PART)
    del XY, DIST, PART
    log("%d parts, %d vertices" % (pid, len(xy)))

    log("sampling DTM")
    z_dtm = sample_raster(DTM, xy)
    log("sampling DSM")
    z_dsm = sample_raster(DSM, xy)
    log("DTM coverage: %.1f%%" % (100 * np.isfinite(z_dtm).mean()))

    log("computing grade")
    g = np.full(len(xy), np.nan)
    edge = np.zeros(len(xy), bool)
    half = RUN / 2.0
    bounds = np.searchsorted(part, np.arange(pid + 1))
    for i in range(pid):
        a, b = bounds[i], bounds[i + 1]
        g[a:b] = profile_grade(z_dtm[a:b])
        d = dist[a:b]
        edge[a:b] = np.minimum(d, d[-1] - d) < half

    disagree = z_dsm - z_dtm
    v = pd.DataFrame({
        "part_id": part,
        "x": xy[:, 0], "y": xy[:, 1],
        "dist_m": dist,
        "z_dtm": z_dtm,
        "dem_disagree_m": disagree,
        "grade_pct": g * 100.0,
        "edge": edge,
        "reliability": assign_reliability(disagree),
    })

    log("attributing to source ways")
    pts = gpd.GeoDataFrame(v[["part_id"]],
                           geometry=gpd.points_from_xy(v.x, v.y), crs=gdf.crs)
    attrs = gdf[["osm_id", "name", "highway", "bridge", "tunnel", "surface", "geometry"]]
    got = []
    for s in range(0, len(pts), CHUNK):
        j = gpd.sjoin_nearest(pts.iloc[s:s + CHUNK], attrs,
                              how="left", max_distance=MAX_JOIN_DIST)
        got.append(j[~j.index.duplicated()].drop(columns="geometry"))
        log("  joined %d / %d" % (min(s + CHUNK, len(pts)), len(pts)))
    j = pd.concat(got)
    for c in ["osm_id", "name", "highway", "bridge", "tunnel", "surface"]:
        v[c] = j[c].values
    v["structure"] = v.bridge.notna() | v.tunnel.notna()
    v.loc[v.structure, "reliability"] = "structure"

    v.to_parquet(out + "_vertices.parquet", index=False)
    log("wrote %s_vertices.parquet" % out)

    # ------------------------------------------------------------ summarise
    core = v[~v.structure & ~v.edge & v.grade_pct.notna()].copy()
    core["ag"] = core.grade_pct.abs()

    def modal(s):
        m = s.mode()
        return m.iloc[0] if len(m) else None

    s = core.groupby("osm_id").agg(
        name=("name", "first"),
        highway=("highway", "first"),
        n_vert=("ag", "size"),
        length_m=("dist_m", "max"),
        grade_med=("ag", "median"),
        grade_p95=("ag", lambda x: np.percentile(x, 95)),
        grade_max=("ag", "max"),
        disagree_med=("dem_disagree_m", "median"),
        reliability=("reliability", modal),
    ).reset_index()

    weak = core.reliability.isin(["low", "unreliable"])
    s = s.merge(core.assign(w=weak).groupby("osm_id").w.mean()
                .mul(100).round(1).rename("pct_low_or_worse").reset_index(),
                on="osm_id", how="left")

    for c in ["grade_med", "grade_p95", "grade_max", "disagree_med"]:
        s[c] = s[c].round(2)
    s["length_m"] = s.length_m.round(1)
    s.to_parquet(out + "_ways.parquet", index=False)

    geo = gdf[["osm_id", "geometry"]].drop_duplicates("osm_id")
    gpd.GeoDataFrame(geo.merge(s, on="osm_id", how="inner"), crs=gdf.crs) \
        .to_parquet(out + ".parquet")
    log("wrote %s.parquet and %s_ways.parquet" % (out, out))

    # ------------------------------------------------------------ report
    pct = lambda x, q: np.percentile(x, q) if len(x) else np.nan
    allv = v[~v.structure & v.grade_pct.notna()].grade_pct.abs()
    print("\n--- %s ---" % out)
    print("vertices total / core      : %d / %d" % (len(v), len(core)))
    print("dropped: structure %d, edge %d, nan %d"
          % (v.structure.sum(), v.edge.sum(), v.grade_pct.isna().sum()))
    print("core   |grade|  med %.2f%%  p95 %.2f%%  max %.2f%%"
          % (core.ag.median(), pct(core.ag, 95), core.ag.max()))
    print("incl. edge      med %.2f%%  p95 %.2f%%  max %.2f%%"
          % (allv.median(), pct(allv, 95), allv.max()))

    by = core.groupby("highway").ag.agg(["size", "median",
                                         lambda x: np.percentile(x, 95)])
    by.columns = ["n", "med", "p95"]
    print("\nby class:\n%s" % by.round(2).to_string())

    rel = core.groupby("reliability").ag.agg(
        n="size", med="median",
        p95=lambda x: np.percentile(x, 95),
        gt20=lambda x: 100 * (x > 20).mean()).round(2)
    rel["share_pct"] = (100 * rel.n / rel.n.sum()).round(1)
    rel["km"] = (core.groupby("reliability").size() * SPACING / 1000).round(0)
    print("\nby reliability:\n%s" % rel.to_string())


if __name__ == "__main__":
    main()
